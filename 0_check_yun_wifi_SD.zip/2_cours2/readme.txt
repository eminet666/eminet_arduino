source : https://www.arduino.cc/en/Tutorial/LibraryExamples
- httpclient
- HttpClientConsole (wifi)
lit un fichier sur le net et l'affiche dans la console
- process (serie)
permet de passer 2 commandes linux (curl, cat)
-ConsolePixel (wifi)
lit donnée à la console et allume/éteint  led 13
- ConsoleRead (wifi)
lit données rentrées à la console
- TimeCheck (serie)
écrit l'heure dans la console
- ConsoleAsciiTable (wifi)
affiche toutes les valeurs de la table ascii dans la console
- FileWriteScipt (serie)
affiche qualité signal wifi et allume led proportionnellement
- Datalogger (serie)
copie les données capturées dans le fichier /mnt/sd/datalog.txt de la carte SD