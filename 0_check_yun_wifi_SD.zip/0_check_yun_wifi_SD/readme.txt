CONFIGURATION
- vérifier présence réseau Arduino-Yun
- YunFirstConfig
- WifiStatus
- test_SD_card
- verifier sur putty : ls /mnt/sda1








DEJA CONFIGURE
- wifi status
- test_SD_card