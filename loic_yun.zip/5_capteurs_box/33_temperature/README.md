# CAPTEUR TEMPERATURE 33

## programmes disponibles
* 1_analog      : test du capteur
* 2_write       : ecriture des données dans un fichier sur la SD
* 3_wifi_html   : accès wifi LAN et interface HTML pour afficher les données
* 4_canvas      : création d'un canvas à partir des données
* 5_refresh     : reload automatique


